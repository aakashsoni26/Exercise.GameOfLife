﻿
namespace Exercise.Games.DomainEntities
{
    public class GameConstants
    {

        // public const string LBL_APPLY = "VALIDATION_ERROR";

        public const string LBL_DEFAULT_SETTINGS = "Default Settings...Visit LifeGrid Constructor to change";
        public const string LBL_INITIAL_MSG = "Input Version of the Grid";
        public const string LBL_NO_LIVE_CELLS_MSG = "Cant proceed ,No live cells exists, ";
        public const string LBL_ITERATION = "Iteration :";
        public const string VALIDATION_ERROR = "VALIDATION_ERROR";



        //public const string VALIDATION_ERROR = "VALIDATION_ERROR";
    }
}
