﻿
namespace Exercise.Games.DomainEntities
{
    public class GameResult : Resources
    {

    }
}
