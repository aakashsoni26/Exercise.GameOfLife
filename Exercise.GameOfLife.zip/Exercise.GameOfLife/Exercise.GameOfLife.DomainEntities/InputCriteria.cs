﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Exercise.Games.DomainEntities.GameOfLife;
using Exercise.Games.DomainEntities;

namespace Exercise.Games.DomainEntities
{
    public class InputResources: Resources
    {
       
    }


}
