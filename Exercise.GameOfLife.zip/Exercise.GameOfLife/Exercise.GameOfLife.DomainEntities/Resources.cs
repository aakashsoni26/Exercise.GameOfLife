﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Exercise.Games.DomainEntities.GameOfLife;

namespace Exercise.Games.DomainEntities
{
    public class Resources
    {
        public LifeGrid LifeGrid { get; set; }
    }
}
